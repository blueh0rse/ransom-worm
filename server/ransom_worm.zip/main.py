import subprocess

subprocess.run("rm ransom_worm.zip", shell=True)